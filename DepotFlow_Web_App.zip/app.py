from flask import Flask, render_template, request, redirect, url_for, flash, make_response
import sqlite3
from datetime import datetime, date, timedelta
from pathlib import Path

app = Flask(__name__)
app.secret_key = "change-this-secret-key"
DB_PATH = Path(__file__).with_name("depot.db")

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    with db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sku TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            cost_price REAL NOT NULL DEFAULT 0,
            selling_price REAL NOT NULL DEFAULT 0,
            stock_qty INTEGER NOT NULL DEFAULT 0,
            reorder_level INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS sales (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER NOT NULL,
            sku TEXT NOT NULL,
            product_name TEXT NOT NULL,
            qty INTEGER NOT NULL,
            unit_price REAL NOT NULL,
            unit_cost REAL NOT NULL,
            revenue REAL NOT NULL,
            cogs REAL NOT NULL,
            profit REAL NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY(product_id) REFERENCES products(id)
        );
        CREATE TABLE IF NOT EXISTS expenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            description TEXT NOT NULL,
            amount REAL NOT NULL,
            created_at TEXT NOT NULL
        );
        """)

def money(value):
    return f"GH₵{value:,.2f}"

@app.context_processor
def inject_helpers():
    return {"money": money}

@app.route("/")
def dashboard():
    with db() as con:
        products = con.execute("SELECT * FROM products ORDER BY name").fetchall()
        totals = con.execute("""
            SELECT COALESCE(SUM(revenue),0) revenue,
                   COALESCE(SUM(cogs),0) cogs,
                   COALESCE(SUM(profit),0) gross_profit,
                   COALESCE(SUM(qty),0) items_sold
            FROM sales
        """).fetchone()
        expenses = con.execute("SELECT COALESCE(SUM(amount),0) total FROM expenses").fetchone()["total"]
        today = date.today().isoformat()
        today_sales = con.execute("SELECT COALESCE(SUM(revenue),0) FROM sales WHERE date(created_at)=?", (today,)).fetchone()[0]
        low_stock = con.execute("SELECT COUNT(*) FROM products WHERE stock_qty <= reorder_level").fetchone()[0]
        stock_value = con.execute("SELECT COALESCE(SUM(stock_qty*cost_price),0) FROM products").fetchone()[0]
        recent = con.execute("SELECT * FROM sales ORDER BY id DESC LIMIT 8").fetchall()
    return render_template("dashboard.html", products=products, totals=totals, expenses=expenses,
                           net_profit=totals["gross_profit"]-expenses, today_sales=today_sales,
                           low_stock=low_stock, stock_value=stock_value, recent=recent)

@app.route("/products", methods=["GET", "POST"])
def products():
    if request.method == "POST":
        try:
            sku = request.form["sku"].strip().upper()
            name = request.form["name"].strip()
            cost = float(request.form["cost_price"])
            price = float(request.form["selling_price"])
            qty = int(request.form["stock_qty"])
            reorder = int(request.form["reorder_level"])
            if not sku or not name or min(cost, price, qty, reorder) < 0:
                raise ValueError()
            with db() as con:
                existing = con.execute("SELECT id FROM products WHERE sku=?", (sku,)).fetchone()
                if existing:
                    con.execute("""UPDATE products SET name=?, cost_price=?, selling_price=?,
                                stock_qty=?, reorder_level=? WHERE sku=?""",
                                (name, cost, price, qty, reorder, sku))
                else:
                    con.execute("""INSERT INTO products(sku,name,cost_price,selling_price,stock_qty,reorder_level,created_at)
                                VALUES(?,?,?,?,?,?,?)""",
                                (sku, name, cost, price, qty, reorder, datetime.now().isoformat(timespec="seconds")))
            flash("Product saved successfully.", "success")
        except (ValueError, KeyError):
            flash("Please enter valid product details. Prices and quantities cannot be negative.", "error")
        except sqlite3.IntegrityError:
            flash("That SKU is already in use.", "error")
        return redirect(url_for("products"))
    with db() as con:
        rows = con.execute("SELECT * FROM products ORDER BY name").fetchall()
    return render_template("products.html", products=rows)

@app.route("/stock-in", methods=["POST"])
def stock_in():
    try:
        product_id = int(request.form["product_id"])
        qty = int(request.form["quantity"])
        if qty <= 0: raise ValueError()
        with db() as con:
            con.execute("UPDATE products SET stock_qty=stock_qty+? WHERE id=?", (qty, product_id))
        flash("Stock quantity updated.", "success")
    except (ValueError, KeyError):
        flash("Enter a valid stock quantity.", "error")
    return redirect(url_for("products"))

@app.route("/sell", methods=["GET", "POST"])
def sell():
    if request.method == "POST":
        try:
            product_id = int(request.form["product_id"])
            qty = int(request.form["qty"])
            if qty <= 0: raise ValueError()
            with db() as con:
                item = con.execute("SELECT * FROM products WHERE id=?", (product_id,)).fetchone()
                if not item: raise ValueError()
                if qty > item["stock_qty"]:
                    flash("Insufficient stock for this sale.", "error")
                    return redirect(url_for("sell"))
                revenue = qty * item["selling_price"]
                cogs = qty * item["cost_price"]
                profit = revenue - cogs
                stamp = datetime.now().isoformat(timespec="seconds")
                con.execute("UPDATE products SET stock_qty=stock_qty-? WHERE id=?", (qty, product_id))
                cur = con.execute("""INSERT INTO sales(product_id,sku,product_name,qty,unit_price,unit_cost,revenue,cogs,profit,created_at)
                                  VALUES(?,?,?,?,?,?,?,?,?,?)""",
                                  (product_id,item["sku"],item["name"],qty,item["selling_price"],item["cost_price"],revenue,cogs,profit,stamp))
                sale_id = cur.lastrowid
            return redirect(url_for("receipt", sale_id=sale_id))
        except (ValueError, KeyError):
            flash("Please select a product and enter a valid quantity.", "error")
            return redirect(url_for("sell"))
    with db() as con:
        items = con.execute("SELECT * FROM products WHERE stock_qty > 0 ORDER BY name").fetchall()
    return render_template("sell.html", products=items)

@app.route("/receipt/<int:sale_id>")
def receipt(sale_id):
    with db() as con:
        sale = con.execute("SELECT * FROM sales WHERE id=?", (sale_id,)).fetchone()
    if not sale:
        flash("Receipt not found.", "error")
        return redirect(url_for("reports"))
    return render_template("receipt.html", sale=sale)

@app.route("/expenses", methods=["GET", "POST"])
def expenses():
    if request.method == "POST":
        try:
            description = request.form["description"].strip()
            amount = float(request.form["amount"])
            if not description or amount <= 0: raise ValueError()
            with db() as con:
                con.execute("INSERT INTO expenses(description,amount,created_at) VALUES(?,?,?)",
                            (description, amount, datetime.now().isoformat(timespec="seconds")))
            flash("Expense recorded.", "success")
        except (ValueError, KeyError):
            flash("Enter a description and a positive amount.", "error")
        return redirect(url_for("expenses"))
    with db() as con:
        rows = con.execute("SELECT * FROM expenses ORDER BY id DESC").fetchall()
        total = con.execute("SELECT COALESCE(SUM(amount),0) FROM expenses").fetchone()[0]
    return render_template("expenses.html", expenses=rows, total=total)

@app.route("/reports")
def reports():
    period = request.args.get("period", "all")
    start = None
    today = date.today()
    if period == "today": start = today.isoformat()
    elif period == "week": start = (today - timedelta(days=6)).isoformat()
    elif period == "month": start = today.replace(day=1).isoformat()
    with db() as con:
        if start:
            sales = con.execute("SELECT * FROM sales WHERE date(created_at)>=? ORDER BY id DESC", (start,)).fetchall()
            summary = con.execute("""SELECT COALESCE(SUM(revenue),0) revenue, COALESCE(SUM(cogs),0) cogs,
                                   COALESCE(SUM(profit),0) profit, COALESCE(SUM(qty),0) qty
                                   FROM sales WHERE date(created_at)>=?""", (start,)).fetchone()
            expense_total = con.execute("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE date(created_at)>=?", (start,)).fetchone()[0]
        else:
            sales = con.execute("SELECT * FROM sales ORDER BY id DESC").fetchall()
            summary = con.execute("""SELECT COALESCE(SUM(revenue),0) revenue, COALESCE(SUM(cogs),0) cogs,
                                   COALESCE(SUM(profit),0) profit, COALESCE(SUM(qty),0) qty FROM sales""").fetchone()
            expense_total = con.execute("SELECT COALESCE(SUM(amount),0) FROM expenses").fetchone()[0]
    return render_template("reports.html", sales=sales, summary=summary, expense_total=expense_total,
                           net=summary["profit"]-expense_total, period=period)

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000, debug=True)
