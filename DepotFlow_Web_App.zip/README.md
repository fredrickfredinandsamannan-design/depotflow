# DepotFlow — Wholesale Depot Web App

A responsive Flask + SQLite inventory and sales application using Ghana cedis (GH₵).

## Features
- Dashboard with revenue, gross profit, estimated net profit, stock value and low-stock count
- Product/SKU management and stock receiving
- Sales recording with automatic stock deduction
- Printable sales receipts
- Operating expense tracking
- Today, last 7 days, this month and all-time reports

## Run locally
1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Create and activate a virtual environment (recommended).
4. Install dependencies: `pip install -r requirements.txt`
5. Start the app: `python app.py`
6. Open `http://127.0.0.1:5000` in your browser.

The SQLite database (`depot.db`) is created automatically on first run.

## Important before public deployment
- Change `app.secret_key` to a long random secret stored in an environment variable.
- Set `debug=False`.
- Use a production WSGI server (such as Waitress or Gunicorn) and HTTPS.
- Add user login/roles and automated backups before using with sensitive business records.
- This starter version is designed for a single business on a trusted network; it does not yet include multi-user authentication or cloud hosting.
